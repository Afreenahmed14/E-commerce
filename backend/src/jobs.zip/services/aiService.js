const genAI = require("../config/gemini");
const ApiError = require('../utils/ApiError');

// const GEMINI_MODEL = process.env.GEMINI_MODEL || "gemini-flash-latest";
const GEMINI_MODEL =
  process.env.GEMINI_MODEL || "models/gemini-flash-latest";

/**
 * Convert OpenAI-style messages ([{role, content}]) into Gemini's format:
 * - system messages become a systemInstruction string
 * - user/assistant messages become {role, parts:[{text}]}
 *   (Gemini uses "model" instead of "assistant")
 */
const toGeminiFormat = (messages) => {
  let systemInstruction = '';
  const contents = [];

  for (const msg of messages) {
    if (msg.role === 'system') {
      systemInstruction += (systemInstruction ? '\n' : '') + msg.content;
    } else {
      contents.push({
        role: msg.role === 'assistant' ? 'model' : 'user',
        parts: [{ text: msg.content }],
      });
    }
  }

  return { systemInstruction, contents };
};

const chatComplete = async (messages, options = {}) => {
  const { systemInstruction, contents } = toGeminiFormat(messages);

  try {
    const response = await genAI.models.generateContent({
      model: GEMINI_MODEL,
      contents,
      // config: {
      //   systemInstruction: systemInstruction || undefined,
      //   temperature: options.temperature ?? 0.6,
      //   maxOutputTokens: options.maxTokens ?? 1000,
      // },
      config: {
  systemInstruction: systemInstruction || undefined,
  temperature: options.temperature ?? 0.6,
  maxOutputTokens: options.maxTokens ?? 1000,
  responseMimeType:
    options.responseMimeType || "text/plain",
},
    });

    const finishReason = response.candidates?.[0]?.finishReason;
    if (finishReason === 'MAX_TOKENS') {
      console.warn(
        `[Gemini] Response was cut off (finishReason=MAX_TOKENS). ` +
        `Consider raising maxTokens for this call — current limit: ${options.maxTokens ?? 1000}`
      );
    }

    return response.text?.trim() || '';
  } catch (err) {
    console.log("========== GEMINI ERROR ==========");
    console.error(err);
    console.log("=================================");
    throw err;
  }
};

const chatCompleteStream = async (messages, onToken, options = {}) => {
  const { systemInstruction, contents } = toGeminiFormat(messages);
  let full = '';

  try {
    const stream = await genAI.models.generateContentStream({
      model: GEMINI_MODEL,
      contents,
      config: {
        systemInstruction: systemInstruction || undefined,
        temperature: options.temperature ?? 0.6,
        maxOutputTokens: options.maxTokens ?? 1000,
      },
    });

    for await (const chunk of stream) {
      const delta = chunk.text;
      if (delta) {
        full += delta;
        onToken(delta);
      }
    }

    return full;
  } catch (err) {
    console.log("========== GEMINI STREAM ERROR ==========");
    console.error(err);
    console.log("=========================================");
    throw err;
  }
};

const extractJSON = async (systemPrompt, userPrompt, options = {}) => {
  const raw = await chatComplete(
    [
      {
        role: 'system',
        content: `${systemPrompt}\n\nRespond ONLY with valid JSON.`,
      },
      {
        role: 'user',
        content: userPrompt,
      },
    ],
    // {
    //   temperature: options.temperature ?? 0.3,
    //   maxTokens: options.maxTokens ?? 4000,
    // }
        {
      temperature: options.temperature ?? 0.3,
      maxTokens: options.maxTokens ?? 4000,
      responseMimeType: "application/json",
    }
  );

  // const cleaned = raw
  //   .replace(/^```json/i, "")
  //   .replace(/```$/i, "")
  //   .trim();

  const cleaned = raw
  .replace(/^```json/i, "")
  .replace(/```$/i, "")
  .trim();

  try {
    return JSON.parse(cleaned);
  } catch (err) {
    console.error("Invalid JSON returned by Gemini:");
    console.error(cleaned);
    throw err;
  }
};

module.exports = {
  chatComplete,
  chatCompleteStream,
  extractJSON,
};  